package com.ignacio.productosycategorias.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ignacio.productosycategorias.models.CategoryModel;
import com.ignacio.productosycategorias.models.ProductModel;

public interface CategoryRepo extends CrudRepository<CategoryModel, Long>{

	List<CategoryModel> findByProductsNotContains(ProductModel producto);
	List<CategoryModel> findAll();
}
