package com.ignacio.productosycategorias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductosycategoriasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductosycategoriasApplication.class, args);
	}

}
