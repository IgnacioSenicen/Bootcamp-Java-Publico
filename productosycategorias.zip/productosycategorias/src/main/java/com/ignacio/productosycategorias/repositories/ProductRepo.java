package com.ignacio.productosycategorias.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ignacio.productosycategorias.models.CategoryModel;
import com.ignacio.productosycategorias.models.ProductModel;


public interface ProductRepo extends CrudRepository<ProductModel, Long>{
List<ProductModel> findByCategoriesNotContains(CategoryModel cat);
List<ProductModel> findAll();
}
