package com.ignacio.licencias.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ignacio.licencias.models.Licencia;

@Repository
public interface LicenciaRepo extends CrudRepository<Licencia, Long> {
	
	public Licencia findTopByOrderByNumberDesc();
	

}
