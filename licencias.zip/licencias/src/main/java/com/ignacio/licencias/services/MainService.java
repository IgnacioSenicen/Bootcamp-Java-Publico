package com.ignacio.licencias.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.ignacio.licencias.models.Licencia;
import com.ignacio.licencias.models.Persona;
import com.ignacio.licencias.repositories.LicenciaRepo;
import com.ignacio.licencias.repositories.PersonaRepo;

@Service
public class MainService {
	// Inyeccion Dependencias
	@Autowired
	private LicenciaRepo licenciarepo;
	@Autowired
	private PersonaRepo personaRepo;
	
	//SERVICIOS PARA PERSONA
	public Persona crearPersona(Persona persona) {
		return personaRepo.save(persona);
	}
	
	public List<Persona> todasPersonas(){
		return personaRepo.findAll();
	}
	
	
	//SERVICIOS PARA LICENCIA
	public Licencia crearLicencia(Licencia licencia) {
		licencia.setNumber(this.generarNumeroLic());
		return licenciarepo.save(licencia);
	}
	
	public List<Persona> obtenerPersonasSinLic(){
		return personaRepo.findByLicenciaIdIsNull();
//		return personaRepo.encontrarNoLic();
	}
	
	public int generarNumeroLic() {
		Licencia lic = licenciarepo.findTopByOrderByNumberDesc();
		if(lic ==null) {
			return 1;
		}
		int numeroMayorLicencia = lic.getNumber();
		numeroMayorLicencia++;
		return numeroMayorLicencia;
		
	}
	
	public Persona findpersona(Long id) {
        Optional<Persona> optionalLang = personaRepo.findById(id);
        if(optionalLang.isPresent()) {
            return optionalLang.get();
        } else {
            return null;
        }
    }
	
}
