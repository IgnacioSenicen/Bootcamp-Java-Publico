package com.FamiliarizarnosConEnrutamiento.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FamiliarizarnosConEnrutamientoApplicationTests {

	@Test
	void contextLoads() {
	}

}
