package com.ignacio.listadeestudiantes.repositories;

import org.springframework.data.repository.CrudRepository;

import com.ignacio.listadeestudiantes.models.ContactInfo;

public interface ContactInfoRepo extends CrudRepository<ContactInfo, Long> {


	
}
