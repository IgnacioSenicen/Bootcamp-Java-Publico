package com.ignacio.listadeestudiantes.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.ignacio.listadeestudiantes.models.Student;

public interface StudentRepo extends CrudRepository<Student, Long> {

	List<Student> findAll();
	@Query(value="SELECT p.* FROM Student p LEFT OUTER JOIN ContactInfo l ON p.id=l.Student_id WHERE l.id IS NULL", nativeQuery=true)
	List<Student> encontrarNoLic();
	
	List<Student> findByContactInfoIdIsNull();
	
	
}
