package com.ignacio.listadeestudiantes.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ignacio.listadeestudiantes.models.ContactInfo;
import com.ignacio.listadeestudiantes.models.Student;
import com.ignacio.listadeestudiantes.repositories.ContactInfoRepo;
import com.ignacio.listadeestudiantes.repositories.StudentRepo;

@Service
public class MainService {
	// Inyeccion Dependencias
	@Autowired
	private ContactInfoRepo contactInfoRepo;
	@Autowired
	private StudentRepo studentRepo;
	
	//SERVICIOS PARA student
	public Student crearStudent(Student student) {
		return studentRepo.save(student);
	}
	
	public List<Student> todosStudent(){
		return studentRepo.findAll();
	}
	
	
	//SERVICIOS PARA ContactInfo
	public ContactInfo crearContactInfo(ContactInfo contactInfo) {
		
		return contactInfoRepo.save(contactInfo);
	}
	
	public List<Student> obtenerStudentSinCont(){
		return studentRepo.findByContactInfoIdIsNull();
//		return personaRepo.encontrarNoLic();
	}
	
	
	public Student findstudent(Long id) {
        Optional<Student> optionalLang = studentRepo.findById(id);
        if(optionalLang.isPresent()) {
            return optionalLang.get();
        } else {
            return null;
        }
    }
	
}
