package com.ignacio.listadeestudiantes.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ignacio.listadeestudiantes.models.ContactInfo;
import com.ignacio.listadeestudiantes.models.Student;
import com.ignacio.listadeestudiantes.services.MainService;

import jakarta.validation.Valid;

@Controller
public class MainController {
	
	// Inyeccion Dependencias
	@Autowired
	private MainService  mainService;
	
	@GetMapping("")
	public String root(Model viewModel) {
		
		List<Student> todosstudents = mainService.todosStudent();
		viewModel.addAttribute("todosstudents", todosstudents);
		return "Index.jsp";
	}
	
	 @RequestMapping("/students/create")
	    public String showStudent(@RequestParam(value="firstName", required=false) String fn, @RequestParam(value="lastName", required=false) String ln , @RequestParam(value="age", required=false) String age ,Model viewModel){
		 Student student = new Student();
		 student.setFirstName(fn);
		 student.setLastName(ln);
		 student.setAge(Integer.parseInt(age));
		 /*searchQueryModel.get("age")*/
		 mainService.crearStudent(student);
		 List<Student> todosstudents = mainService.todosStudent();
			viewModel.addAttribute("todosstudents", todosstudents);
		 return "Index.jsp";
	    }
	 @RequestMapping("/contacts/create")
	    public String showLesson(@RequestParam(value="student", required=false) String studentid,@RequestParam(value="address", required=false) String address,@RequestParam(value="city", required=false) String city,@RequestParam(value="state", required=false) String state,Model viewModel){
		 ContactInfo contact = new ContactInfo();
		 Student student = new Student();
		 student=mainService.findstudent(convertToLong(studentid));
		 contact.setStudent(student);
		 contact.setAddress(address);
		 contact.setCity(city);
		 contact.setState(state);
		 
		 mainService.crearContactInfo(contact);
		 
		 return "redirect:/";
	    }
	
	@GetMapping("/persons/new")
	public String formularioPersona(@ModelAttribute("student")Student student) {
		
		
		return "newperson.jsp";
	}
	
	@PostMapping("/persons/new")
	public String crearPersona(@Valid@ModelAttribute("student")Student student, BindingResult resultado) {
		
		if(resultado.hasErrors()) {
			return "newperson.jsp";
		}
		mainService.crearStudent(student); 
		return "redirect:/";
		
	}
	
	@GetMapping("/licencias/new")
	public String formularioLicencia(@ModelAttribute("licencia")ContactInfo contactInfo, Model viewModel) {
		
		/*List<Persona> todosUsuarios = mainService.todasPersonas();
		viewModel.addAttribute("personas",todosUsuarios);*/
		viewModel.addAttribute("personas", mainService.obtenerStudentSinCont());
		return "newlic.jsp";
	}
	@PostMapping("/licencias/new")
	public String crearLicencia(@Valid@ModelAttribute("licencia")ContactInfo contactInfo, BindingResult resultado, Model viewModel) {
		
		if(resultado.hasErrors()) {
			/*List<Persona> todosUsuarios = mainService.todasPersonas();
			viewModel.addAttribute("personas",todosUsuarios);*/
			viewModel.addAttribute("personas", mainService.obtenerStudentSinCont());
			return "newlic.jsp";
		}
		mainService.crearContactInfo(contactInfo); 
		
		return "redirect:/";
	}
	

	@GetMapping("/persona/{id}")
	public String ver(@PathVariable("id") Long id, Model model) {
		Student student = mainService.findstudent(id);
	    model.addAttribute("student", student);
	    return "/showinfo.jsp";
	}
	
	public static long convertToLong(String strNum) {
		long valor;
		try {
		valor = Long.parseLong(strNum);
		} catch (NumberFormatException | NullPointerException nfe) {
		return 0; //Valor default en caso de no poder convertir a Long
		}
		return valor;
		}
		
}
