public class Project  {
    private String nombre ;
    private String descripcion;
    
    
    public Project () {
    }
    public Project (String nombre) {
        this.nombre = nombre;
    }   
    public Project (String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion  = descripcion;
    }

    public String getnombre() {
        return nombre;
    }
    public String getdescripcion() {
        return descripcion;
    }
    // setters
    public void setnombre(String nombre) {
        nombre = nombre;
    }
    public void setdescripcion(String descripcion) {
        descripcion = descripcion;
    }

    public String elevatorPitch (){
    return nombre  + ":" + descripcion;
} 
    
    
}


