class Projecttest {
    public static void main(String[] args) {
        Project bike = new Project();
        Project Auto = new Project("Auto");
        Project Camion = new Project("Camion","No enciende");

       
        System.out.println(bike.elevatorPitch());
        System.out.println(Auto.elevatorPitch());
        System.out.println(Camion.elevatorPitch());
        System.out.println(Camion.getdescripcion());
    }
}

