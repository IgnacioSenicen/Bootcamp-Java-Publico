package com.ignacio.Contador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContadorApplication.class, args);
	}

}
