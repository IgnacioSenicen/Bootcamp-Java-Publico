public class TestPit {
    public static void main(String[] args) {
        double catetoA=12.0;
        double catetoB=13.0;

        TeoremaPit calculador = new TeoremaPit();
        double resultado = calculador.calcularHipotenusa(catetoA, catetoB);
        System.out.println("El resultado es: " + resultado);
    }
}