public class TeoremaPit {
    public double calcularHipotenusa(double catetoA, double catetoB) {
        double resultado=0.0;
        resultado = Math.pow(catetoA,2)+Math.pow(catetoB,2);
        resultado = Math.sqrt(resultado);

return resultado;
    }
}

