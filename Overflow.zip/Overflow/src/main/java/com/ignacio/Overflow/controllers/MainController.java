package com.ignacio.Overflow.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ignacio.Overflow.models.Answers;
import com.ignacio.Overflow.models.Questions;
import com.ignacio.Overflow.models.Tags;
import com.ignacio.Overflow.models.tagsquestions;
import com.ignacio.Overflow.service.QuestionService;

import jakarta.validation.Valid;

@Controller
public class MainController {

private final QuestionService questionServ;
	
	public MainController(QuestionService qSer) {
		this.questionServ = qSer;
		
	}
	
	@GetMapping("/")
	public String raiz(Model viewModel) {
		return "redirect:/questions";
	}
	
	@GetMapping("/questions")
	public String bienvenida( Model viewModel) {
		
		
		viewModel.addAttribute("questions", questionServ.allquestions() );
		return "dashboard.jsp";
	
}
	
	
	@GetMapping("/questions/{idque}")
	public String questionProfile(@ModelAttribute("ans") Answers ans ,@PathVariable("idque") Long idque,  Model viewModel) {
		viewModel.addAttribute("questions", questionServ.unaQuestion(idque) );
		return "QuestionProfile.jsp";
	}
	
	@PostMapping("/question/{idque}")
	public String questionProfile( @Valid @ModelAttribute("ans") Answers ans,BindingResult resultado, @PathVariable("idque") Long idque,  Model viewModel) {
		if (resultado.hasErrors()) {
			viewModel.addAttribute("questions", questionServ.unaQuestion(idque) );
			return "QuestionProfile.jsp";
		}
		Questions question = questionServ.unaQuestion(idque);
		ans.setQuestions(question);
		questionServ.crearAnswers(ans);
		/*question.getAnswers().add(ans);
		questionServ.crearquestions(question);*/
		viewModel.addAttribute("questions", questionServ.unaQuestion(idque) );
		return "redirect:/questions/"+idque;
	}
	
	
	@GetMapping("/question/new")
	public String newQuestion(@ModelAttribute("question") Questions question) {
		 
		return "NewQuestion.jsp";
	}
	
	
	
	
	@PostMapping("/question/new")
	public String crearQuestion(@Valid @ModelAttribute("question") Questions question,BindingResult resultado, @RequestParam("etiquetas") String etiquetas ,  Model viewModel, RedirectAttributes redirectAttributes) {
		if (resultado.hasErrors()) {
			return "NewQuestion.jsp";
		}
		///ArrayList<Tags> parts=question.getTags();
		List<Tags> tagList = new ArrayList<>();
		String[] arregloetiquetas = etiquetas.split(",");
		
		if(arregloetiquetas.length>3) {
			redirectAttributes.addFlashAttribute("error", "No agregues mas de 3 tags");
			return "redirect:/question/new";
		}
		
		for(String temaEtiqueta : arregloetiquetas) {
			String unaEtiqueta = temaEtiqueta.trim().toLowerCase();
			Tags existeEtiqueta = questionServ.existeTag(unaEtiqueta);
			//Si no exixte el tag, entonces crea el tag
			if(existeEtiqueta==null) {
				Tags nuevaEtiqueta = new Tags();
				nuevaEtiqueta.setSubject(unaEtiqueta);
				tagList.add(nuevaEtiqueta);
				questionServ.crearTags(nuevaEtiqueta);
			}
			else {
				tagList.add(existeEtiqueta);
			}
			
		}
		//guarda los tags y la pregunta en la base de datos
		question.setTags(tagList);
		questionServ.crearquestions(question);
		
		/*for(Tags etiqueta : tagList ) {
			tagsquestions tagquestion = new tagsquestions();
			tagquestion.setQuestions(question);
			tagquestion.setTags(etiqueta);
			//questionServ.bind(question.getId(), etiqueta.getId());
			questionServ.creartagsquestions(tagquestion);
		}*/
		
		return "redirect:/questions";
	}
	
}
	
	

