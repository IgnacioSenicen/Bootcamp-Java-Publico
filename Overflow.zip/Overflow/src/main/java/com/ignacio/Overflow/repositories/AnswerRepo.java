package com.ignacio.Overflow.repositories;

import org.springframework.data.repository.CrudRepository;

import com.ignacio.Overflow.models.Answers;

public interface AnswerRepo extends CrudRepository<Answers, Long> {

}
