package com.ignacio.Overflow.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ignacio.Overflow.models.Answers;
import com.ignacio.Overflow.models.Questions;
import com.ignacio.Overflow.models.Tags;
import com.ignacio.Overflow.models.tagsquestions;
import com.ignacio.Overflow.repositories.AnswerRepo;
import com.ignacio.Overflow.repositories.QuestionRepo;
import com.ignacio.Overflow.repositories.TagsQuestionsRepo;
import com.ignacio.Overflow.repositories.TagsRepo;




@Service

public class QuestionService {
	
	private final QuestionRepo questionRepo;
	private final TagsRepo tagsRepo;
	private final TagsQuestionsRepo tagsQuestionsRepo;
	private final AnswerRepo answerRepo;
	public QuestionService(QuestionRepo iRe,TagsRepo trp,TagsQuestionsRepo tqrp, AnswerRepo ar) {
		this.questionRepo = iRe;
		this.tagsRepo = trp;
		this.tagsQuestionsRepo = tqrp;
		this.answerRepo = ar;
		
	}
	
	public Answers crearAnswers(Answers answers) {
		return answerRepo.save(answers);
	}
	public Questions crearquestions(Questions questions) {
		return questionRepo.save(questions);
	}
	public List<Questions> allquestions() {
        return questionRepo.findAll();
    }
	
	public Tags existeTag(String nombreTag) {
		
		return tagsRepo.findBysubject(nombreTag);
	}
	public Tags crearTags(Tags tag) {
		return tagsRepo.save(tag);
	}
	/*public int bind (Long id,Long id2) {
		 return tagsQuestionsRepo.bindtagquestion(id,id2);
	}*/
	public Questions unaQuestion(Long id) {
		return questionRepo.findById(id).orElse(null);
	}
	public Tags unTag(Long id) {
		return tagsRepo.findById(id).orElse(null);
	}
	
	public tagsquestions creartagsquestions(tagsquestions tagQuestion) {
		return tagsQuestionsRepo.save(tagQuestion);
	}

}
