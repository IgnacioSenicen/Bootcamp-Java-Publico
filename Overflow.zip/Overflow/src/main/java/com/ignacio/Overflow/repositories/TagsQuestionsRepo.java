package com.ignacio.Overflow.repositories;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.ignacio.Overflow.models.tagsquestions;

public interface TagsQuestionsRepo extends CrudRepository<tagsquestions, Long> {
	
	/*@Modifying
	@Query("update tagsquestions t set t.questions_id = ?1, t.tags_id = ?2;")
	int bindtagquestion(Long id,Long id2);*/

}
