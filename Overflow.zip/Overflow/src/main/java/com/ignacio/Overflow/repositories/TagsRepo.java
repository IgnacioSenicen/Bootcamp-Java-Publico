package com.ignacio.Overflow.repositories;

import org.springframework.data.repository.CrudRepository;

import com.ignacio.Overflow.models.Tags;

public interface TagsRepo extends CrudRepository<Tags,Long> {
	
	Tags findBysubject(String subject);
	
	

}
