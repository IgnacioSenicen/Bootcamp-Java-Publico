package com.ignacio.countries.controllers;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.ignacio.countries.models.countries;
import com.ignacio.countries.models.languages;
import com.ignacio.countries.services.MainService;
@Controller
public class MainController {

	private final MainService mainService;
	

	public MainController(MainService ms) {
		this.mainService = ms;
	
	}
	
	@GetMapping("")
	public String ejercicios(Model viewModel) {
		
		//List<String> table= mainService.Ejercicio1();
		//List<String> table= mainService.Ejercicio2();
		//List<String> table= mainService.Ejercicio3();
		//List<String> table= mainService.Ejercicio4();
		//List<String> table= mainService.Ejercicio5();
		//List<String> table= mainService.Ejercicio6();
		//List<String> table= mainService.Ejercicio7();
		List<String> table= mainService.Ejercicio8();
		viewModel.addAttribute("table", table);
		
		return "dashboard.jsp";
	}
	
}
