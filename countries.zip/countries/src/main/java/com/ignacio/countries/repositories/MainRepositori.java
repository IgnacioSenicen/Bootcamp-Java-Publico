package com.ignacio.countries.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.ignacio.countries.models.countries;

public interface MainRepositori  extends CrudRepository<countries, Long>{

	  @Query("select c.name, l.language, l.percentage from countries c join c.languages l where language ='Slovene' order by percentage desc")
	  List<String> Ejercicio1();
	  @Query("select c.name,COUNT(ct) as citiesn from countries c join c.cities ct group by c order by citiesn desc")
	  List<String> Ejercicio2();
	  @Query("select ct.name, ct.population as pop from countries c join c.cities ct where c.name ='Mexico' and ct.population>500000 order by pop desc ")
	  List<String> Ejercicio3();
	  @Query("select c.name, l.language, l.percentage from countries c join c.languages l where percentage>89 order by percentage desc ")
	  List<String> Ejercicio4();
	  @Query("select c.name, c.surfaceArea, c.population from countries c where c.surfaceArea<501 and c.population>100000 ")
	  List<String> Ejercicio5();
	  @Query("select c.name, c.governmentForm, c.surfaceArea, c.lifeExpectancy from countries c where c.governmentForm='Constitutional Monarchy' and c.surfaceArea>200 and c.lifeExpectancy>75 ")
	  List<String> Ejercicio6();
	  @Query("select c.name, ct.name, ct.district, ct.population from countries c join c.cities ct where ct.district='Buenos Aires' and ct.population>500000 ")
	  List<String> Ejercicio7();
	  @Query("select c.region, COUNT(c) as ncountries from countries c group by region order by ncountries desc ")
	  List<String> Ejercicio8();
	
}
