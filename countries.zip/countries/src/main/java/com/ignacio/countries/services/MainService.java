package com.ignacio.countries.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ignacio.countries.repositories.MainRepositori;
@Service
public class MainService {

	private final MainRepositori mainRepositori;
	public MainService(MainRepositori Mrp) {
		this.mainRepositori = Mrp;
	}
	
	public List<String> Ejercicio1() {
		
		List<String> table = mainRepositori.Ejercicio1();
		
		return table;
		
		}
	public List<String> Ejercicio2() {
		
		List<String> table = mainRepositori.Ejercicio2();
		
		return table;
		
		}
	public List<String> Ejercicio3() {
		
		List<String> table = mainRepositori.Ejercicio3();
		
		return table;
		
		}
	public List<String> Ejercicio4() {
		
		List<String> table = mainRepositori.Ejercicio4();
		
		return table;
		
		}
	public List<String> Ejercicio5() {
		
		List<String> table = mainRepositori.Ejercicio5();
		
		return table;
		
		}
	public List<String> Ejercicio6() {
		
		List<String> table = mainRepositori.Ejercicio6();
		
		return table;
		
		}
	public List<String> Ejercicio7() {
		
		List<String> table = mainRepositori.Ejercicio7();
		
		return table;
		
		}
	public List<String> Ejercicio8() {
		
		List<String> table = mainRepositori.Ejercicio8();
		
		return table;
		
		}
	
	
}
