function warning(){
    alert("Esta es la plantilla de Fecha") /* genera un alert */
}
function warning2(){
    alert("Esta es la plantilla de Hora Actual") /* genera un alert */
}