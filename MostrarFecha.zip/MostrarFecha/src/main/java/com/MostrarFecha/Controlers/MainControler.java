package com.MostrarFecha.Controlers;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller

public class MainControler {
	@RequestMapping("/")
public String home() {
	return "index.jsp";
}
	
    @GetMapping("/date")
	public String fecha(Model modelos) {
		
		SimpleDateFormat fechas = new SimpleDateFormat("EEEE, MMM d, yyyy");
		Date fechaActual = new Date();
		
		modelos.addAttribute("fecha", fechas.format(fechaActual));
		
		return "fecha.jsp";
	}	
    
    @GetMapping("/time")
	public String hora(Model modelos) {
		
		SimpleDateFormat hora = new SimpleDateFormat("HH:mm:ss,a");
		Date horaActual = new Date();
		
		modelos.addAttribute("fecha", hora.format(horaActual));
		
		return "hora.jsp";
	}	
	
	
	
	
	
}
