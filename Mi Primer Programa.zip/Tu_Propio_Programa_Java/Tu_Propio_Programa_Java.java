public class Tu_Propio_Programa_Java {
    public static void main(String[] args) {
        System.out.println("Mi nombre es Ignacio");
        System.out.println("Tengo 20 años de edad");
        System.out.println("Mi ciudad es Tigre");
    }
}