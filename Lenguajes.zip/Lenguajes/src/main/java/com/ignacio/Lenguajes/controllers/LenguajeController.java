package com.ignacio.Lenguajes.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;


import com.ignacio.Lenguajes.models.LenguajeModel;
import com.ignacio.Lenguajes.services.LenguajeService;

import jakarta.validation.Valid;



@Controller
public class LenguajeController {
	
	//Inyeccion Depencioas
	
	 private final LenguajeService lenguajeservice;
	 
	 public LenguajeController(LenguajeService lenguajeservices){
	        this.lenguajeservice = lenguajeservices;}
	    
	
	
	
	/*@Autowired
	private LenguajeService lenguajeservice = lenguajeservice;*/
	
	@GetMapping("/")
	public String index() {
		return "redirect:/languajes";
	}
	
	@GetMapping("/languajes")
    public String Languajes( @ModelAttribute("lenguajemodel") LenguajeModel lenguajes, BindingResult result,Model model) {
        List<LenguajeModel> lenguaje = lenguajeservice.alllenguajes();
        model.addAttribute("lenguaje", lenguaje);
        return "Languajes.jsp";
    }
	
	@PostMapping("/languajesc")
    public String LanguajesC(@Valid @ModelAttribute("lenguajemodel") LenguajeModel lenguajes, BindingResult result,Model model) {
		List<LenguajeModel> lenguaje = lenguajeservice.alllenguajes();
        model.addAttribute("lenguaje", lenguaje);
        
		if(result.hasErrors()) {
			return "Languajes.jsp";
		}else {
			lenguajeservice.addlenguaje(lenguajes);
			return "redirect:/languajes";
		}
		
    }
	
	
	@GetMapping("/language/edit/{id}")
	public String edit(@PathVariable("id") Long id, Model model) {
		LenguajeModel lenguaje = lenguajeservice.findlanguage(id);
	    model.addAttribute("lenguajemodel", lenguaje);
	    return "/JavaEdit.jsp";
	}
	
	@PutMapping("/language/{id}")
	public String update(@Valid @ModelAttribute("lenguajemodel") LenguajeModel lenguajes, BindingResult result) {
	    if (result.hasErrors()) {
	        return "/JavaEdit.jsp";
	    } else {
	    	
	    	lenguajeservice.addlenguaje(lenguajes);
	    	return "redirect:/languajes";
	    }
	}
	
	
	@GetMapping("/language/{id}")
	public String ver(@PathVariable("id") Long id, Model model) {
		LenguajeModel lenguaje = lenguajeservice.findlanguage(id);
	    model.addAttribute("lenguajemodel", lenguaje);
	    return "/Java.jsp";
	}
	
	@DeleteMapping("/language/{id}/delete")
	public String destroy(@PathVariable("id") Long id) {
		lenguajeservice.borrarRegistro(id);
		return "redirect:/languajes";

	}

}
