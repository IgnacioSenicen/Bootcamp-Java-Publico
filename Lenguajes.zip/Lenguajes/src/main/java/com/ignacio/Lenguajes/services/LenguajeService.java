package com.ignacio.Lenguajes.services;



import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;


import com.ignacio.Lenguajes.models.LenguajeModel;
import com.ignacio.Lenguajes.repositories.LenguajeRepo;

@Service
public class LenguajeService {
	private final LenguajeRepo lenguajeRepo;
	
	public LenguajeService(LenguajeRepo lenguajeRepo) {
		this.lenguajeRepo = lenguajeRepo;
	}
	
	 public List<LenguajeModel> alllenguajes() {
		 	
	        return lenguajeRepo.findAll();
	    }
	public LenguajeModel addlenguaje(LenguajeModel lenguajemodel) {
		
		return lenguajeRepo.save(lenguajemodel);
	}
	
	 //Obteniendo la información de un lenguaje
    public LenguajeModel findlanguage(Long id) {
        Optional<LenguajeModel> optionalLang = lenguajeRepo.findById(id);
        if(optionalLang.isPresent()) {
            return optionalLang.get();
        } else {
            return null;
        }
    }
    
  //Actualizar Informacion
    public LenguajeModel actualizarLenguaje(LenguajeModel lenguajemodel) {
    	LenguajeModel temporal = findlanguage(lenguajemodel.getId());
    	temporal.setLenguaje(lenguajemodel.getLenguaje());
    	temporal.setCreador(lenguajemodel.getCreador());
    	temporal.setVersion(lenguajemodel.getVersion());
    	
    	return lenguajeRepo.save(temporal);
    }
    
  //Borrar un Registro
    public void borrarRegistro(Long id) {
    	lenguajeRepo.deleteById(id);
    }

}
