package com.ignacio.Lenguajes.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


import com.ignacio.Lenguajes.models.LenguajeModel;



public interface LenguajeRepo extends CrudRepository<LenguajeModel, Long> {

	//Este método recupera todos los libros de la base de datos
    List<LenguajeModel> findAll();
	
}
