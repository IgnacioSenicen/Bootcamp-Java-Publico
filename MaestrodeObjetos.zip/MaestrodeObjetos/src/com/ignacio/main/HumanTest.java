package com.ignacio.main;
import com.ignacio.especies.Human;

public class HumanTest {
	
		public static void main(String[] args) {
			Human Hector = new Human();
			Human Aquiles = new Human();
			Hector.setName("Hector");
			Aquiles.setName("Aquiles");
			
			
			System.out.println("Vida de Hector: "+Hector.getHealth());
			System.out.println("Vida de Aquiles: "+Aquiles.getHealth());
			Hector.attack(Aquiles);
			System.out.println("Vida de Aquiles: "+Aquiles.getHealth());
			Aquiles.attack(Hector);
			System.out.println("Vida de Hector: "+Hector.getHealth());
		
		
		
		
	}
}
