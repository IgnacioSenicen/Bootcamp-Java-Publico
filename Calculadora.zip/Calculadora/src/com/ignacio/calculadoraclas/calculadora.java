package com.ignacio.calculadoraclas;

public class calculadora implements java.io.Serializable {

	private double OperandOne;
	private String operation;
	private double OperandTwo;
	private double Result;
	
	public calculadora(){
    }
	
	public void performOperation() {
		
		if(operation=="+") 
		{
			Result = OperandOne + OperandTwo;
		}
		else if(operation=="-") 
		{
			Result = OperandOne - OperandTwo;
		}
		else{System.out.println("Operacion incorrecta");}
		
		
	}
	
	
	public void setOperandOne(double operandOne) {
		OperandOne = operandOne;
	}
	
	public void setoperation(String Operation) {
		operation = Operation;
	}
	
	public void setOperandTwo(double operandTwo) {
		OperandTwo = operandTwo;
	}
	public double getResult() {
		return Result;
	}
	
	
	
	
	
}
