package com.ignacio.calculadoramain;

import com.ignacio.calculadoraclas.calculadora;

public class calculadoraTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calculadora calc = new calculadora();
		calc.setOperandOne(10.5);
		calc.setOperandTwo(5.2);
		calc.setoperation("+");
		calc.performOperation();
		System.out.println("El resultado es: " + calc.getResult());
	}

}
